console.log("Telegram bot started");
